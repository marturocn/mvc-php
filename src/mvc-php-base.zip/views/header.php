<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title></title>
        <link rel="stylesheet" href="./public/css/default.css">
    </head>
    <body>
        <div id="header">
            <ul>
                <li><a href="main">Inicio</a></li>
                <li><a href="nuevo">Nuevo</a></li>
                <li><a href="consulta">Consulta</a></li>
                <li><a href="ayuda">Ayuda</a></li>
            </ul>
        </div>
    </body>
</html>
