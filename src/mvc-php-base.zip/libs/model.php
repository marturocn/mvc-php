<?php

class Model {
    function __construct() {
    }
}

?>
