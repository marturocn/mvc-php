<?php

class Controller {
    function __construct() {
        //echo "<p>Base Controller</p>";
        $this->view = new View();
    }
}

?>
